<?php
	include('teacher.php');
	class Classteacher extends Teacher {
		 public function __construct()
        {
                parent::__construct();
        }
		function test () {
			echo "привет";
		}
	}
	?>
