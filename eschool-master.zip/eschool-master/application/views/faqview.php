<style type="text/css">
	body {
		background-image: url(../images/bg.png);
	    background-repeat: repeat;
    }
    .panel-default {
	    background: #563d7c;
	    color: white;
    }

</style>
<div class="container">
	<div class="row">
			<table>
				<tr>
					<td>
						<div class="panel panel-default">
							<div class="panel-body">
								<div class="page-header">
									<h1>Example page header <small>Subtext for header</small></h1>
								</div>
							</div>
						</div>
					</td>
					<td>
						<img src="<?php echo base_url();?>images/img5.png" class="img-responsive" alt="Responsive image">
					</td>
				</tr>
				<tr>
					<td>
						<img src="<?php echo base_url();?>images/img2.png" class="img-responsive" alt="Responsive image">
					</td>
					<td>
						<div class="panel panel-default">
							<div class="panel-body">
								Basic panel example
						    </div>
					    </div>
					</td>
				</tr>
				<tr>
					<td>
						<div class="panel panel-default">
							<div class="panel-body">
								<div class="page-header">
									<h1>Example page header <small>Subtext for header</small></h1>
								</div>
							</div>
						</div>
					</td>
					<td>
						<img src="<?php echo base_url();?>images/img1.png" class="img-responsive" alt="Responsive image">
					</td>
				</tr>

			</table>

				</div>

</div>