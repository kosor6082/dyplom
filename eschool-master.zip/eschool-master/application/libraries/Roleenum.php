<?php
	class Roleenum {
    	const ClassTeacher = 1;
    	const Admin = 2;	
    	const Teacher = 3;
    	const Pupil = 4;
	}